package com.example.rabbitMQ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitMqApplicationTests {

	@Test
	void contextLoads() {
	}

}
